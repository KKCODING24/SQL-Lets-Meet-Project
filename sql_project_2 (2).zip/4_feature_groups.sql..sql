select
count(*)
from grp
where rating=5;



select case
when rating between "1" and "1.99" then "1"
when rating between "2" and "2.99" then"2"
when rating between "3" and "3.99" then "3"
when rating between "4" and "4.99" then "4"
when rating ="0" then "no rating"
else 5 end as rating_cat,
count(group_id),
group_name
from grp
group by rating_cat
order by rating_cat;

Select
Count(*)
from (grp);

select
count(*)
from grp
where rating=5;

/*select 
(4340)/(745);/*



/*select
rating,
members,
group_name
from grp
where rating=5
order by members;*/


select
rating,
members,
group_name,
city
from grp
left join city on grp.city_id=city.city_id
where rating=5
order by members;





