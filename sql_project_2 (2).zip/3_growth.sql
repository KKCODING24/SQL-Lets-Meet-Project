select
	join_yr, 
	count(join_yr)
from 
	(select 
		member_id, year(min(joined)) as join_yr
	from grp_member
	group by member_id) yr
group by join_yr
order by join_yr desc;

set sql_safe_updates = 0;


Update grp_member
set city= "chicago"
where city= ("east chicago","west chicago","north chicago","chicago heights","chicago ridge");

update 
grp_member
set city="san francisco"
where city= "south Francisco";

update grp_member
set city= "new york"
where city="west new york";

select join_yr, count(join_yr)
from
(select member_id, year(min(joined)) join_yr
from grp_member
where city ="chicago"
group by member_id)yr
group by join_yr
order by join_yr desc;

select join_yr, count(join_yr)
from
(select member_id, year(min(joined)) join_yr
from grp_member
where city ="San Francisco"
group by member_id)yr
group by join_yr
order by join_yr desc;

select join_yr, count(join_yr)
from
(select member_id, year(min(joined)) join_yr
from grp_member
where city ="New York"
group by member_id)yr
group by join_yr
order by join_yr desc;

select join_mnth, count(join_mnth)
from
(select member_id, month(min(joined)) join_mnth
from grp_member
where year (joined) =2017
group by member_id)mnth
group by join_mnth
order by join_mnth;
