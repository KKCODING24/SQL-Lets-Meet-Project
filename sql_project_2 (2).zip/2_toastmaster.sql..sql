select
event_name
from event
where event_name like "%toastmaster%";

select
city,
count(city)
from grp
join event on event.group_id=grp.group_id
join city on city.city_id=grp.city_id
where event.event_name like"%oastmaster%"
group by city;

select
city,
count(city)
from grp
join event on event.group_id=grp.group_id
join city on city.city_id=grp.city_id
where event.event_name like"%oastmaster%"
group by city
order by event_name;





