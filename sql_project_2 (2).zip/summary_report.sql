-- Summary of Findings
-- Use this file to summarize your findings and make your recommendations where they have been requested.
-- Any recommendations should include the data to support why you are making that recommendation

-- 1. How many Toastmasters events are there using LetsMeet in New York, Chicago and San Francisco?
-- There are 7 Toastmaster events in San Francisco, 124 events in New York, and 986 events in Chicago. 



-- 2. Is LetsMeet membership leveling off?
-- The membership growth has grown significantly, since 2003, which started out with four members
-- As of 2017, there are 10,486 members. Membership continued to grow for all three cities
-- New York and San Francisco have more membership gowth then Chicago from 2015-2017
-- New York has the highest amount of growth, second would be San Franisco, finally Chicago 





-- 3. What five groups should marketing feature in their upcoming campaign

/*The five groups that the marketing team should feature in their upcoming campaing should be the groups that have the most members with a 5 star rating. The 5 groups are the following:
-NYC Art Meetup has 9,082 members
-NYC local Singles & Professional Get Togethers has 5776 members
-New York Travel Photoraphy has 4786 members
-Chicago Young Professionals has 4057 members
-Create and Chat has 2752*/
