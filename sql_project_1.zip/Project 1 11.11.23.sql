-- Answer the questions from the Sales team in this file.


-- Active Cities
select
distinct city
from grp_member
where member_status="active";
(select distinct city, state
from city
where city not in); 









-- Groups
select
*
from grp;

select
join_mode,
count(*)
from grp
group by join_mode;
-- There are 3602 groups with the open status, 723 waiting on approval, and 15 closed.


--








-- Categories
select
g.category_id,
c.category_name,
count(*)
from grp
join c on g.category_id=c.category.id
group by g.category_id
order by count(*) desc
limit 5;




-- Members
SELECT 
    COUNT(*)
FROM
    grp_member;
SELECT 
    SUM(member_count) AS total_member
FROM
    city;
SELECT (43470 * 100 / 382351)



