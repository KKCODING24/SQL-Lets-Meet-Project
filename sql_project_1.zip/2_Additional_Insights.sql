-- Venue
SELECT 
    city, COUNT(DISTINCT venue_name)
FROM
    venue_
GROUP BY city;

SELECT 
    city, zip, venue_name
FROM
    venue_
GROUP BY venue_name
ORDER BY zip DESC
LIMIT 10;
/*New York has has the most venues. The zip code that has the most venues is 94133. San Francisco is the neighborhood. Based on the data, LetsMeet can see that there are more than enough venues in New York and San Francisco so it should be easier to continue to grow and establish new groups in these two areas*/

-- GRP
SELECT 
    visibility, COUNT(*)
FROM
    grp
WHERE
    visibility = 'public_limited';

SELECT 
    created, group_name, members
FROM
    grp
ORDER BY created DESC;
/*The longest running group on LetsMeet would be the Successful Business6 Analyst in an Agile Enviornment group. There are 4 members in the group. There are 514 groups that are Public Limited. Public Limited means the visibilty for the group is limited to the public. This could be due to the group organizers and members wanting to limited the amount of content and information that is visible to a non-member. Since there are only 4 members that belong to the above mentioned group, possibly creating more networking events could possbly help the group to continue to grow.*/



-- Grp_Member
SELECT 
    joined, member_status, 
    COUNT(member_name)
FROM
    grp_member
ORDER BY joined ASC;

SELECT DISTINCT
    (member_name), COUNT(grp.group_id)
FROM
    grp
        JOIN
    grp_member ON grp.group_id = grp_member.group_id
GROUP BY member_name;
/*Christine was the first LetsMeet member. David is involved in the most groups. Encourage members to continue to network and be open to joining multiple groups*/

-- City
/*The ranking column would be how the members rank the city they network and meetup in. Members would rank on venues, coffee shops, lounges, and hotels. Rankings could also be useful for group organizers.Looking at the city table, there isnt enough data to analyze.There are cities that contain "0" rankings*/


-- Event
SELECT 
    AVG(duration) AS average_seconds,
    AVG(duration) / 60 AS average_minutes,
    (AVG(duration) / 60) / 60 AS average_hours
FROM
    event;
    /*The average duration of all events is 3 hours. Since the average duration of the events is no more than 3 hours, I would recommend keeping the 2-3 hour duration*/
select
venue_id,
venue_name,
event.venue_id
from venue_
left join event on venue.venue_id=event.venue_id;

-- Category
/*In the sales insights tab, I joined the category table and the group table to find what category has the most groups. Based on the queries, I would start by using the category and group table to try and find out the most popular category.*/


