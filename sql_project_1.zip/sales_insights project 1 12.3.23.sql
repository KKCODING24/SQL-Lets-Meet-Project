-- Answer the questions from the Sales team in this file.


-- Active Cities
SELECT DISTINCT
    city
FROM
    grp_member
WHERE
    member_status = 'active';
SELECT DISTINCT
    city, state
FROM
    city
WHERE
    city NOT IN (SELECT DISTINCT
            city
        FROM
            grp_member
        WHERE
            member_status = 'active');
/*What cities have active members?
Are there any cities listed in the city table with no active members? If so, what state are those cities in?
New York, San Francisco, Chicago, West New York, West Chicago, South San Francisco, Chicaco Heights, and East Chicago have active members. 
There are no active members in New York Mills, Ny, NY Mills, MN, and Chicago Park, CA. I would recommend focusing on the cities that are thriving right now with networking events, and cities that offer plenty of access to venues*/


-- Groups
SELECT 
    join_mode, COUNT(*)
FROM
    grp
GROUP BY join_mode;
/*How many groups are currently open, waiting for approval, and/or closed? There are currently 3602 groups open, 723 groups waiting on approval, and 15 groups closed. Group organizers could reach out to the members to find out what information is still pending in order to move forward in the approval process*/


-- Categories
SELECT 
    grp.category_id,
    category.category_id,
    category_name,
    COUNT(*)
FROM
    grp
        JOIN
    category ON grp.category_id = category.category_id
GROUP BY grp.category_id
ORDER BY COUNT(*) DESC
LIMIT 5;

SELECT 
    grp.category_id,
    category.category_id,
    category_name,
    COUNT(*)
FROM
    grp
        JOIN
    category ON grp.category_id = category.category_id
GROUP BY grp.category_id
ORDER BY COUNT(*)
LIMIT 5;
/* What are the five categories that contain the most groups? What are the five categories that contain the least number of groups?
The five categories that contain the most groups are Tech, Career & Business, Socializing, Health & Wellbeing, and Language & Ethnic Identity. The five categories that contain the least number of groups are Paranormal, Cars & Motorcycles, Sci-Fi & Fantasy, Lifestyle, and Hobbies and Crafts. The groups that hold the least amount of members, look into recruiting more members*/

-- Members
SELECT 
    COUNT(DISTINCT member_id)
FROM
    grp_member;
SELECT 
    COUNT(DISTINCT city)
FROM
    grp_member
WHERE
    city = chicago;
SELECT (43470 * 100 / 382351);
/*How many members are there? What percentage of members are in Chicago? There are 43,470 members. Chicago has 11.37% of members. Chicago makes up a small percentage of members, I think the focus should be to try and expand and create more groups and events. Consider opening a Tech, Health and Well Being, Language and Ethnic Identity, Career and Busnness, and Socializing category since they were found to have the most groups*/