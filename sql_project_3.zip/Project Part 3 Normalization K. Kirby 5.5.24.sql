
alter table venue_
drop column address_2;
/*The address _2 column should be removed as there is no use to address two addresses for a venue*/

alter table venue_
drop column country;
/*LetsMeet operates in the USA only. The country would not add any value to the data analysis*/

alter table city
drop column localized_country_name;
/* The column is not needed since it does not add any value to the analysis. Localized County Name is in reference to 
USA counties being name to fit the local culture or language*/

alter table city
drop column distance;
/* The Distance column can be removed. The distance column does not specify the distance from where? 
Not knowing if the data provided is the distanc from tourist attractions, public transportaton, etc. should not be included*/

alter table event
drop column visibility;
/*The Visibility column would be uninformative information for the analysis. If your using this column f
or marketing purposes or search engine results, I dont see this column adding any value*/ 

CREATE TABLE group_sign_ups AS SELECT DISTINCT group_id, member_id, joined FROM
    grp_member;

CREATE TABLE members AS SELECT DISTINCT member_id, member_name, member_status, city FROM
    grp_member;

alter table members
add primary key(member_id);

alter table group_sign_ups
add foreign key(member_id) references members(member_id);

alter table group_sign_ups
add foreign key (group_id) references grp(group_id);

drop table grp_member;






